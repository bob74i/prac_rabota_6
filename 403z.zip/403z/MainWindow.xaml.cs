﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using CheckBox = System.Windows.Controls.CheckBox;
using MessageBox = System.Windows.MessageBox;
using Window = System.Windows.Window;


namespace _403z
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private DB_Babaev _context; // Имя контекста
 
        public MainWindow()
        {
            InitializeComponent();
            _context = new DB_Babaev(); // Инициализация контекста 
        }

        private void lName_GotFocus(object sender, RoutedEventArgs e)
        {
            // Очистка текста при получении фокуса
            if (lName.Text == "Иванов")
            {
                lName.Text = "";
                lName.Foreground = Brushes.Black;
            }
        }

        private void name_GotFocus(object sender, RoutedEventArgs e)
        {
            if (name.Text == "Иван")
            {
                name.Text = "";
                name.Foreground = Brushes.Black;
            }
        }

        private void eMail_GotFocus(object sender, RoutedEventArgs e)
        {
            if (eMail.Text == "ivanov@gmail.com")
            {
                eMail.Text = "";
                eMail.Foreground = Brushes.Black;
            }
        }

        private void passw_GotFocus(object sender, RoutedEventArgs e)
        {
            if (passw.Password == "********")
            {
                passw.Password = "";
                passw.Foreground = Brushes.Black;
            }
        }

        private void repPass_GotFocus(object sender, RoutedEventArgs e)
        {
            if (repPass.Password == "********")
            {
                repPass.Password = "";
                repPass.Foreground = Brushes.Black;
            }
        }

        private void word_GotFocus(object sender, RoutedEventArgs e)
        {
            if (word.Text == "фунтик")
            {
                word.Text = "";
                word.Foreground = Brushes.Black;
            }
        }

        private void otvet_GotFocus(object sender, RoutedEventArgs e)
        {
            if (otvet.Text == "Париж")
            {
                otvet.Text = "";
                otvet.Foreground = Brushes.Black;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
            // Заполнение ComboBox секретными вопросами 
            var secretQuestions = _context.СекретныйВопрос.ToList();
            quest.ItemsSource = secretQuestions;
            quest.DisplayMemberPath = "СекретныйВопрос1";       //свойство которое отображается
            quest.SelectedValuePath = "КодСекретногоВопроса";   //свойство котророе используется как значение
            quest.SelectedIndex = 0;  // Установка первого вопроса по умолчанию
        }
        
        private void lName_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
       
        private void name_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void eMail_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void word_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void qwest_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void otvet_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SignIn_Click(object sender, RoutedEventArgs e)
        {
            // проверка пароля и повтора пароля
            if (passw.Password != repPass.Password)
            {
                MessageBox.Show("Пароли не совпадают", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // проверка длинны пароля
            if (passw.Password.Length < 6)
            {
                MessageBox.Show("Пароль должен содержать не менее 6 символов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Проверка согласия с условиями
            if (!((CheckBox)FindName("checkBox")).IsChecked ?? false)
            {
                MessageBox.Show("Необходимо согласится с условиями", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //Создание нового пользователя
            var newUser =new Пользователь
            {
                Фамилия = lName.Text,
                Имя = name.Text,
                ЭлектроннаяПочта = eMail.Text,
                Пароль = passw.Password,
                КодовоеСлово = word.Text,
                КодСекретногоВопроса = (int)quest.SelectedValue, // сохраняем код выбранного вопроса
                ОтветНаСекретныйВопрос = otvet.Text
            };

            // Сохранение пользователя в базе данных
            _context.Пользователь.Add(newUser);
            _context.SaveChanges();

            // Вывод сообщения об успешной регистрации
            MessageBox.Show("Регистрация прошла успешно!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Go_Click(object sender, RoutedEventArgs e)
        {
            // логика для перехода на следующую страницу или выполнение другого действия
            MessageBox.Show("Переход на следущую страницу...", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
